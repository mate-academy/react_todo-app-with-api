export enum ErrorType {
  Endpoint,
  Add,
  Update,
  Delete,
  Title,
  None = '',
}
