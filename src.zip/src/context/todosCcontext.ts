import { useState, createContext } from 'react';
import { Todo } from '../types/Todo';

export const TodoContext = createContext({
  todos: [],
  setTodos: () => {},
});

export const TodoProvider = ({ children }) => {
  const [todos, setTodos] = useState<Todo[]>([]);

  const contextValue = {
    todos,
    setTodos,
  };
};
